client_script {
	"menu.lua"
}


